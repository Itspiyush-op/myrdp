const {
  ApplicationCommandOptionType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const { MainClient, Commands, Context } = require("../../Structures/index.js");

class Flags extends Commands {
  constructor(client) {
    super(client, {
      name: "flags",
      description: "Start the flag-rolling game!",
      usage: "flags <flag-emoji>",
      cooldown: 60,
      aliases: [],
      category: "Custom",
      args: true,
      slash: true,
      options: [
        {
          name: "flag",
          description: "Select a flag emoji to roll for.",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: ["ManageMessages"],
      botPermissions: ["ManageMessages"],
    });
  }
  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let selectedFlag = ctx.interaction
      ? ctx.interaction.options.getString("flag")
      : args[0];

    let flagEmojis = [
      "🇦🇫",
      "🇦🇱",
      "🇩🇿",
      "🇦🇸",
      "🇦🇩",
      "🇦🇴",
      "🇦🇮",
      "🇦🇶",
      "🇦🇬",
      "🇦🇷",
      "🇦🇲",
      "🇦🇺",
      "🇦🇹",
      "🇦🇿",
      "🇧🇸",
      "🇧🇭",
      "🇧🇩",
      "🇧🇧",
      "🇧🇾",
      "🇧🇪",
      "🇧🇿",
      "🇧🇯",
      "🇧🇲",
      "🇧🇹",
      "🇧🇴",
      "🇧🇦",
      "🇧🇼",
      "🇧🇷",
      "🇮🇴",
      "🇧🇳",
      "🇧🇬",
      "🇧🇫",
      "🇧🇮",
      "🇨🇻",
      "🇰🇭",
      "🇨🇲",
      "🇨🇦",
      "🇨🇫",
      "🇹🇩",
      "🇨🇱",
      "🇨🇳",
      "🇨🇴",
      "🇰🇲",
      "🇨🇩",
      "🇨🇷",
      "🇭🇷",
      "🇨🇺",
      "🇨🇾",
      "🇨🇿",
      "🇩🇰",
      "🇩🇯",
      "🇩🇲",
      "🇩🇴",
      "🇪🇨",
      "🇪🇬",
      "🇸🇻",
      "🇬🇶",
      "🇪🇷",
      "🇪🇪",
      "🇪🇹",
      "🇫🇯",
      "🇫🇮",
      "🇫🇷",
      "🇬🇦",
      "🇬🇲",
      "🇬🇪",
      "🇩🇪",
      "🇬🇭",
      "🇬🇷",
      "🇬🇩",
      "🇬🇹",
      "🇬🇳",
      "🇬🇼",
      "🇬🇾",
      "🇭🇹",
      "🇭🇳",
      "🇭🇰",
      "🇭🇺",
      "🇮🇸",
      "🇮🇳",
      "🇮🇩",
      "🇮🇷",
      "🇮🇶",
      "🇮🇪",
      "🇮🇱",
      "🇮🇹",
      "🇨🇮",
      "🇯🇲",
      "🇯🇵",
      "🇯🇴",
      "🇰🇿",
      "🇰🇪",
      "🇰🇮",
      "🇽🇰",
      "🇰🇼",
      "🇰🇬",
      "🇱🇦",
      "🇱🇻",
      "🇱🇧",
      "🇱🇸",
      "🇱🇷",
      "🇱🇾",
      "🇱🇮",
      "🇱🇹",
      "🇱🇺",
      "🇲🇴",
      "🇲🇰",
      "🇲🇬",
      "🇲🇼",
      "🇲🇾",
      "🇲🇻",
      "🇲🇱",
      "🇲🇹",
      "🇲🇭",
      "🇲🇶",
      "🇲🇷",
      "🇲🇺",
      "🇲🇽",
      "🇫🇲",
      "🇲🇩",
      "🇲🇨",
      "🇲🇳",
      "🇲🇪",
      "🇲🇸",
      "🇲🇦",
      "🇲🇿",
      "🇲🇲",
      "🇳🇦",
      "🇳🇷",
      "🇳🇵",
      "🇳🇱",
      "🇳🇨",
      "🇳🇿",
      "🇳🇮",
      "🇳🇪",
      "🇳🇬",
      "🇳🇺",
      "🇲🇵",
      "🇰🇵",
      "🇳🇴",
      "🇴🇲",
      "🇵🇰",
      "🇵🇼",
      "🇵🇸",
      "🇵🇦",
      "🇵🇬",
      "🇵🇾",
      "🇵🇪",
      "🇵🇭",
      "🇵🇱",
      "🇵🇹",
      "🇵🇷",
      "🇶🇦",
      "🇷🇴",
      "🇷🇺",
      "🇷🇼",
      "🇰🇳",
      "🇱🇨",
      "🇻🇨",
      "🇼🇸",
      "🇸🇲",
      "🇸🇦",
      "🇸🇳",
      "🇷🇸",
      "🇸🇨",
      "🇸🇱",
      "🇸🇬",
      "🇸🇰",
      "🇸🇮",
      "🇸🇧",
      "🇸🇴",
      "🇿🇦",
      "🇰🇷",
      "🇸🇸",
      "🇪🇸",
      "🇱🇰",
      "🇸🇩",
      "🇸🇷",
      "🇸🇿",
      "🇸🇪",
      "🇨🇭",
      "🇸🇾",
      "🇹🇼",
      "🇹🇯",
      "🇹🇿",
      "🇹🇭",
      "🇹🇱",
      "🇹🇬",
      "🇹🇴",
      "🇹🇹",
      "🇹🇳",
      "🇹🇷",
      "🇹🇲",
      "🇹🇻",
      "🇺🇬",
      "🇺🇦",
      "🇦🇪",
      "🇬🇧",
      "🇺🇸",
      "🇺🇾",
      "🇺🇿",
      "🇻🇺",
      "🇻🇦",
      "🇻🇪",
      "🇻🇳",
      "🇾🇪",
      "🇿🇲",
      "🇿🇼",
    ];

    if (!flagEmojis.includes(selectedFlag)) {
      return await ctx
        .sendMessage({
          content: `${
            client.config.emoji.cross
          } | Invalid flag emoji! Please choose from: ${flagEmojis.join(" ")}`,
          ephemeral: true,
        })
        .then(async (m) => await ctx.deleteMessage(m, 10000));
    }

    let randomFlag = flagEmojis[Math.floor(Math.random() * flagEmojis.length)];

    let gameEmbed = client
      .embed()
      .setAuthor({
        name: `${ctx.author.displayName} Started the roll the flags game!`,
        iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
      })
      .setTitle("Roll The Flags")
      .setDescription("A new round has started! Try to roll the matching flag!")
      .addField({
        name: "Flag to find",
        value: `${selectedFlag}`,
        inline: true,
      })
      .setTimestamp();

    let row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("roll")
        .setLabel("🎲 Roll")
        .setStyle(ButtonStyle.Primary)
    );

    const message = await ctx.sendMessage({
      embeds: [gameEmbed],
      components: [row],
    });

    const collector = message.createMessageComponentCollector({
      time: 5 * 60 * 1000,
    });
  }
}

module.exports = Flags;
