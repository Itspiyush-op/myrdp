const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType, ChannelType } = require("discord.js");

class Lottery extends Commands {
  constructor(client) {
    super(client, {
      name: "lottery",
      description:
        "Collect data and assign a role when a trigger message is sent in the lottery channel.",
      usage: "lottery <setup | reset> <amount> <@role> [#channel]",
      cooldown: 10,
      aliases: [],
      category: "Custom",
      args: false,
      slash: true,
      options: [
        {
          name: "setup",
          description: "Set up lottery collection.",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "amount",
              description: "Enter the trigger amount.",
              type: ApplicationCommandOptionType.Integer,
              min_value: 1,
              max_value: 100000000,
              required: true,
            },
            {
              name: "role",
              description: "Select the role to assign.",
              type: ApplicationCommandOptionType.Role,
              required: true,
            },
            {
              name: "channel",
              description:
                "Select the channel to trigger in (default is current channel).",
              type: ApplicationCommandOptionType.Channel,
              required: false,
              channel_types: [ChannelType.GuildText],
            },
          ],
        },
        {
          name: "reset",
          description: "Reset the lottery setup.",
          type: ApplicationCommandOptionType.Subcommand,
        },
      ],
      devOnly: false,
      slashOnly: true,
      userPermissions: ["Administrator"],
      botPermissions: ["ManageRoles"],
    });
  }

  /**
   *
   * @param {MainClient} client
   * @param {Context} ctx
   */
  async execute(client, ctx) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    let subCommands = ctx.interaction.options.getSubcommand();
    let trigger = ctx.interaction.options.getInteger("amount");
    let role = ctx.interaction.options.getRole("role");
    let channel = ctx.interaction.options.getChannel("channel") || ctx.channel;

    switch (subCommands) {
      case "setup":
        await client.db.setLottery(ctx.guild.id, trigger, role.id, channel.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Lottery setup successfully completed!`
            ),
          ],
        });
        break;
      case "reset":
        await client.db.deleteLottery(ctx.guild.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Lottery setup successfully reset!`
            ),
          ],
        });
        return;
      default:
        await ctx.sendMessage({
          embeds: [
            embed
              .setDescription(
                `${client.config.emoji.cross} | An unexpected error occurred. Please try again.`
              )
              .setColor("Red"),
          ],
        });
        break;
    }
  }
}

module.exports = Lottery;
