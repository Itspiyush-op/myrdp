const { Commands, MainClient, Context } = require("../../Structures/index.js");
const {
  PermissionFlagsBits,
  ApplicationCommandOptionType,
} = require("discord.js");

class Manage extends Commands {
  constructor(client) {
    super(client, {
      name: "manage",
      description: "Edit the name or description of the current channel.",
      usage: "manage <name | description> <input>",
      cooldown: 10,
      aliases: [],
      category: "Custom",
      args: true,
      slash: true,
      options: [
        {
          name: "choice",
          description: "Select a choice",
          type: ApplicationCommandOptionType.String,
          required: true,
          choices: [
            {
              name: "Channel Name",
              value: "name",
            },
            {
              name: "Channel Description",
              value: "description",
            },
          ],
        },
        {
          name: "input",
          description: "Enter the new channel name or description",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      devOnly: false,
      slashOnly: true,
      userPermissions: [],
      botPermissions: ["ManageChannels"],
    });
  }

  async execute(client, ctx) {
    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    let choice = ctx.interaction.options.getString("choice");
    let input = ctx.interaction.options.getString("input");

    if (
      !ctx.channel
        .permissionsFor(ctx.member)
        .has(PermissionFlagsBits.ManageChannels)
    ) {
      return await ctx.sendMessage({
        content: `${client.config.emoji.cross} | You don't have **ManageChannels** permission!`,
        ephemeral: true,
      });
    }

    try {
      switch (choice) {
        case "name":
          await ctx.channel.setName(input);
          embed.setDescription(
            `${client.config.emoji.tick} | Channel name has been updated to: **${input}**`
          );
          await ctx.sendMessage({ embeds: [embed] });
          break;
        case "description":
          await ctx.channel.setTopic(input);
          embed.setDescription(
            `${client.config.emoji.tick} | Channel description has been updated to: **${input}**`
          );
          await ctx.sendMessage({ embeds: [embed] });
          break;
        default:
          break;
      }
    } catch (err) {
      await ctx.sendMessage({
        content: `${client.config.emoji.cross} | An error occurred while trying to update the channel`,
        ephemeral: true,
      });
    }
  }
}

module.exports = Manage;
