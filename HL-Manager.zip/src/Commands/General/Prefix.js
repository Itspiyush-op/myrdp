const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType } = require("discord.js");

class Prefix extends Commands {
  constructor(client) {
    super(client, {
      name: "prefix",
      description: "Change / Reset the guild prefix!",
      usage: "prefix <set | reset> <new-prefix>",
      cooldown: 10,
      aliases: [],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "set",
          description: "Sets the prefix",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "prefix",
              description: "The prefix you want to set",
              type: ApplicationCommandOptionType.String,
              required: true,
            },
          ],
        },
        {
          name: "reset",
          description: "Reset the prefix to the default one",
          type: ApplicationCommandOptionType.Subcommand,
        },
      ],
      devOnly: true,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }
  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let defaultPrefix = await client.db.getPrefix(ctx.guild.id);

    if (ctx.isInteraction) {
      this.subCommands = ctx.interaction.options.getSubcommand();
      this.prefix =
        ctx.interaction.options.getString("prefix") || client.config.prefix;
    } else {
      this.subCommands = args[0];
      this.prefix = args[1];
    }

    let embed = client.embed().setAuthor({
      name: client.user.displayName,
      iconURL: client.user.displayAvatarURL({ dynamic: true }),
    });

    switch (this.subCommands) {
      case "set":
        if (!this.prefix) {
          embed
            .setColor("Red")
            .setDescription(
              `${client.config.emoji.cross} | Please provide new prefix`
            );
          return await ctx.sendMessage({ embeds: [embed] });
        }

        this.prefix = this.prefix.toLowerCase();
        if (this.prefix.length > 3)
          return await ctx.sendMessage({
            embeds: [
              embed
                .setDescription(
                  `${client.config.emoji.cross} | The prefix can't be longer than 3 characters`
                )
                .setColor("Red"),
            ],
          });

        if (!defaultPrefix) {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Changed!, New Prefix Is: ${this.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, this.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        } else {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Changed!, New Prefix Is: ${this.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, this.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        }
        break;
      case "add":
        if (!this.prefix) {
          embed
            .setColor("Red")
            .setDescription(
              `${client.config.emoji.cross} | Please provide new prefix`
            );
          return await ctx.sendMessage({ embeds: [embed] });
        }

        this.prefix = this.prefix.toLowerCase();
        if (this.prefix.length > 3)
          return await ctx.sendMessage({
            embeds: [
              embed
                .setDescription(
                  `${client.config.emoji.cross} | The prefix can't be longer than 3 characters`
                )
                .setColor("Red"),
            ],
          });

        if (!defaultPrefix) {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Changed!, New Prefix Is: ${this.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, this.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        } else {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Changed!, New Prefix Is: ${this.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, this.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        }
        break;

      case "reset":
        if (!defaultPrefix) {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Reset!, Default Prefix Is: ${client.config.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, client.config.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        } else {
          embed.setDescription(
            `${client.config.emoji.tick} | Successfully Reset!, Default Prefix Is: ${client.config.prefix}`
          );
          await client.db.setPrefix(ctx.guild.id, client.config.prefix);
          await ctx.sendMessage({ embeds: [embed] });
        }

      default:
        break;
    }
  }
}

module.exports = Prefix;
