const { Commands, MainClient, Context } = require("../../Structures/index.js");
const { ApplicationCommandOptionType } = require("discord.js");

class Profile extends Commands {
  constructor(client) {
    super(client, {
      name: "profile",
      description: "View your profile or another user's profile",
      usage: "profile <@user>",
      cooldown: 10,
      aliases: ["p"],
      category: "General",
      args: false,
      slash: true,
      options: [
        {
          name: "user",
          description: "The user to view the profile of",
          type: ApplicationCommandOptionType.User,
          required: false,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    let user;
    let embed = client.embed().setAuthor({
      name: client.user.displayName,
      iconURL: client.user.displayAvatarURL({ dynamic: true }),
    });
    await ctx.sendDeferMessage({
      content: `${client.config.emoji.load} Processing...`,
    });
    if (ctx.isInteraction) {
      user = ctx.interaction.options.getUser("user") || ctx.author;
    } else {
      user =
        ctx.message.mentions.users.first() ||
        (await client.users.fetch(args[0]).catch((_) => null));
    }
    if (!user) user = ctx.author;

    let data = await client.db.getBadges(user.id);
    let text = `Name: ${user.displayName}\nUsername: ${user.username}\nMention: <@${user.id}>\nUserID: ${user.id}`;

    text += `\nCreated At: <t:${Math.floor(
      user.createdTimestamp / 1000
    )}:F> (<t:${Math.floor(user.createdTimestamp / 1000)}:R>)`;

    embed.setAuthor({
      name: `${user.displayName}'s Profile`,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    embed
      .setFields({ name: `${user.displayName}'s Information`, value: text })
      .addFields({ name: `Badges [${data.length}]`, value: data.join("\n") });
    embed
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: `Requested by ${ctx.author.displayName}` })
      .setTimestamp();

    await ctx.editMessage({ content: null, embeds: [embed] });
  }
}

module.exports = Profile;
