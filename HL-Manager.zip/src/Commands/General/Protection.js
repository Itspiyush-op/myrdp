const { ApplicationCommandOptionType } = require("discord.js");
const { Commands, Context, MainClient } = require("../../Structures/index.js");

class Protection extends Commands {
  constructor(client) {
    super(client, {
      name: "protection",
      description: "Manage user protection settings.",
      usage: "protection <add | remove | removeall>",
      aliases: ["protect"],
      cooldown: 10,
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "add",
          description: "Add a user to protection",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "user",
              description: "Select a user to add to protection",
              type: ApplicationCommandOptionType.User,
              required: true,
            },
          ],
        },
        {
          name: "remove",
          description: "Remove a user from protection",
          type: ApplicationCommandOptionType.Subcommand,
          options: [
            {
              name: "user",
              description: "Select a user to remove from protection",
              type: ApplicationCommandOptionType.User,
              required: true,
            },
          ],
        },
        {
          name: "removeall",
          description: "Remove protection from all users",
          type: ApplicationCommandOptionType.Subcommand,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: ["ManageChannels"],
      botPermissions: ["ManageChannels"],
    });
  }

  /**
   * @param { MainClient } client
   * @param { Context } ctx
   */

  async execute(client, ctx, args) {
    let subcommand, user;

    if (ctx.isInteraction) {
      subcommand = ctx.interaction.options.getSubcommand();
      user = ctx.interaction.options.getUser("user");
    } else {
      subcommand = args[0];
      user =
        ctx.message.mentions.users.first() ||
        (await ctx.guild.members.cache.get(args[1]).catch((_) => null));
    }

    let embed = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });

    if (subcommand !== "removeall" && !user) {
      return await ctx.sendMessage({
        embeds: [
          embed
            .setColor("Red")
            .setDescription(`${client.config.emoji.cross} | User not found!`),
        ],
      });
    }

    switch (subcommand) {
      case "add":
        await client.db.addUserToProtection(ctx.guild.id, user.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Added **${user.username}** to protection!`
            ),
          ],
        });
        break;

      case "remove":
        await client.db.removeUserFromProtection(ctx.guild.id, user.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Removed **${user.username}** from protection!`
            ),
          ],
        });
        break;

      case "removeall":
        await client.db.removeAllUsersFromProtection(ctx.guild.id);
        await ctx.sendMessage({
          embeds: [
            embed.setDescription(
              `${client.config.emoji.tick} | Removed protection from all users!`
            ),
          ],
        });
        break;

      default:
        await ctx.sendMessage({
          embeds: [
            embed
              .setColor("Red")
              .setDescription(`${client.config.emoji.cross} | Invalid action!`),
          ],
        });
        break;
    }
  }
}

module.exports = Protection;
