const { Commands, MainClient, Context } = require("../../Structures/index.js");
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ApplicationCommandOptionType,
} = require("discord.js");
const ytSearch = require("yt-search");

class Search extends Commands {
  constructor(client) {
    super(client, {
      name: "search",
      description: "Search for a YouTube video",
      usage: "search <query>",
      cooldown: 10,
      aliases: [],
      category: "General",
      args: true,
      slash: true,
      options: [
        {
          name: "query",
          description: "Search query for the video",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */
  async execute(client, ctx, args) {
    await ctx.sendDeferMessage(`${client.config.emoji.load} Searching...`);
    let query;
    if (ctx.isInteraction) {
      query = ctx.interaction.options.getString("query");
    } else {
      query = args.join(" ");
    }

    const embed = client.embed().setAuthor({
      name: client.user.username,
      iconURL: client.user.displayAvatarURL({ dynamic: true }),
    });

    if (!query) {
      embed
        .setDescription(
          `${client.config.emoji.cross} | Please provide a search query.`
        )
        .setColor("Red");
      return await ctx.editMessage({ content: null, embeds: [embed] });
    }

    const result = await ytSearch(query);
    const video = result.videos.length > 0 ? result.videos[0] : null;

    if (!video) {
      embed
        .setDescription(`${client.config.emoji.cross} | No results found.`)
        .setColor("Red");
      return await ctx.editMessage({ content: null, embeds: [embed] });
    }

    embed
      .setTitle(video.title)
      .setURL(video.url)
      .setThumbnail(video.thumbnail)
      .addFields(
        { name: "Channel", value: video.author.name, inline: true },
        { name: "Views", value: video.views.toLocaleString(), inline: true },
        { name: "Duration", value: video.timestamp, inline: true }
      )
      .setFooter({ text: `Uploaded ${video.ago}` });

    let row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setURL(video.url)
        .setStyle(ButtonStyle.Link)
        .setLabel("Play Video on YouTube")
    );
    await ctx.editMessage({
      content: null,
      embeds: [embed],
      components: [row],
    });
  }
}

module.exports = Search;
