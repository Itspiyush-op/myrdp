const translate = require("@iamtraction/google-translate");
const { ApplicationCommandOptionType } = require("discord.js");
const { Commands, MainClient, Context } = require("../../Structures/index.js");

class Translate extends Commands {
  constructor(client) {
    super(client, {
      name: "translate",
      description: "Translates a message to a specified language!",
      usage: "translate <text> --<language>",
      cooldown: 5,
      aliases: ["tr", "ts", "tl"],
      category: "General",
      args: false,
      slash: true,
      options: [
        {
          name: "text",
          description: "Provide the text to translate!",
          type: ApplicationCommandOptionType.String,
          required: true,
        },
        {
          name: "language",
          description: "Provide the language to translate ( Default: EN )",
          type: ApplicationCommandOptionType.String,
          required: false,
        },
      ],
      devOnly: false,
      slashOnly: false,
      userPermissions: [],
      botPermissions: [],
    });
  }

  /**
   *
   * @param { MainClient } client
   * @param { Context } ctx
   */

  async execute(client, ctx, args) {
    this.languageMap = {
      af: "Afrikaans",
      sq: "Albanian",
      am: "Amharic",
      ar: "Arabic",
      hy: "Armenian",
      az: "Azerbaijani",
      eu: "Basque",
      be: "Belarusian",
      bn: "Bengali",
      bs: "Bosnian",
      bg: "Bulgarian",
      ca: "Catalan",
      ceb: "Cebuano",
      ny: "Chichewa",
      zh: "Chinese",
      co: "Corsican",
      hr: "Croatian",
      cs: "Czech",
      da: "Danish",
      nl: "Dutch",
      en: "English",
      eo: "Esperanto",
      et: "Estonian",
      tl: "Filipino",
      fi: "Finnish",
      fr: "French",
      fy: "Frisian",
      gl: "Galician",
      ka: "Georgian",
      de: "German",
      el: "Greek",
      gu: "Gujarati",
      ha: "Hausa",
      haw: "Hawaiian",
      iw: "Hebrew",
      hi: "Hindi",
      hmn: "Hmong",
      hu: "Hungarian",
      is: "Icelandic",
      ig: "Igbo",
      id: "Indonesian",
      ga: "Irish",
      it: "Italian",
      ja: "Japanese",
      jw: "Javanese",
      kn: "Kannada",
      kk: "Kazakh",
      km: "Khmer",
      ko: "Korean",
      ky: "Kyrgyz",
      lo: "Lao",
      la: "Latin",
      lv: "Latvian",
      lt: "Lithuanian",
      lb: "Luxembourgish",
      mk: "Macedonian",
      mg: "Malagasy",
      ms: "Malay",
      ml: "Malayalam",
      mt: "Maltese",
      mi: "Maori",
      mr: "Marathi",
      mn: "Mongolian",
      ne: "Nepali",
      no: "Norwegian",
      or: "Odia",
      ps: "Pashto",
      fa: "Persian",
      pl: "Polish",
      pt: "Portuguese",
      pa: "Punjabi",
      ro: "Romanian",
      ru: "Russian",
      sm: "Samoan",
      gd: "Scots Gaelic",
      sr: "Serbian",
      st: "Sesotho",
      sn: "Shona",
      sd: "Sindhi",
      si: "Sinhala",
      sk: "Slovak",
      sl: "Slovenian",
      so: "Somali",
      es: "Spanish",
      su: "Sundanese",
      sw: "Swahili",
      sv: "Swedish",
      tg: "Tajik",
      ta: "Tamil",
      te: "Telugu",
      th: "Thai",
      tr: "Turkish",
      uk: "Ukrainian",
      ur: "Urdu",
      uz: "Uzbek",
      vi: "Vietnamese",
      cy: "Welsh",
      xh: "Xhosa",
      yi: "Yiddish",
      yo: "Yoruba",
      zu: "Zulu",
    };

    let text;
    let lang;
    let embed1 = client.embed().setAuthor({
      name: ctx.author.displayName,
      iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
    });
    let embed2 = client.embed();

    if (ctx.isInteraction) {
      text = ctx.interaction.options.getString("text");
      lang = ctx.interaction.options.getString("language") || "English";
    } else {
      text = args.join(" ");

      let input = text;
      let match = input.match(/^(.*?)(?:\s+--([a-zA-Z]+))$/);
      text = match ? match[1].trim() : null || text;
      lang = match ? match[2].trim().toLowerCase() : "English";
    }

    if (!text)
      return await ctx.sendMessage({
        embeds: [
          embed1
            .setDescription(
              `${client.config.emoji.cross} | Please provide text to translate.`
            )
            .setColor("Red"),
        ],
      });

    if (!lang)
      return await ctx.sendMessage({
        embeds: [
          embed1
            .setDescription(
              `${client.config.emoji.cross} | Please specify the target language using --<language>.`
            )
            .setColor("Red"),
        ],
      });

    const iso = this.languageToISO(lang);
    if (!iso === "Unknown ISO Code")
      return await ctx.sendMessage({
        embeds: [
          embed1
            .setDescription(
              `${client.config.emoji.cross} | Invalid language. Please provide a valid language.`
            )
            .setColor("Red"),
        ],
      });

    try {
      const response = await translate(text, { to: this.languageToISO(lang) });
      await ctx.sendMessage({
        embeds: [
          embed1
            .setTitle(`From ${this.isoToLanguage(response.from.language.iso)}`)
            .setDescription(text)
            .setFooter(null),
          embed2
            .setDescription(response.text)
            .setTitle(`To ${this.isoToLanguage(this.languageToISO(lang))}`),
        ],
      });
    } catch (error) {
      client.logger.error("Unable to translate!");
    }
  }
  isoToLanguage(code) {
    return this.languageMap[code] || "Unknown Language";
  }

  languageToISO(language) {
    let isoCode = Object.keys(this.languageMap).find(
      (key) => this.languageMap[key].toLowerCase() === language.toLowerCase()
    );
    return isoCode || "Unknown ISO Code";
  }
}

module.exports = Translate;
