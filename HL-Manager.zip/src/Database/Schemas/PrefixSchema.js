const { Schema, model } = require("mongoose");

const prefixSchema = new Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
  },
  prefix: {
    type: String,
    required: true,
    default: "!",
  },
});

module.exports = model("Prefixs", prefixSchema);
