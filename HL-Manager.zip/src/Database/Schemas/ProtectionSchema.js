const { Schema, model } = require("mongoose");

const protectionSchema = new Schema({
  guildId: { type: String, unique: true, required: true },
  usersArray: [{ type: String, default: [] }],
});

module.exports = model("Protection", protectionSchema);
