const { Schema, model } = require("mongoose");

const stickySchema = new Schema({
  channelId: {
    type: String,
    required: true,
    unique: true,
  },
  message: {
    type: String,
    required: true,
  },
  oldMessageId: {
    type: String,
    required: true,
    unique: true,
  },
});

module.exports = model("Sticky", stickySchema);
