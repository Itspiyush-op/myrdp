const { Events, MainClient, Context } = require("../../Structures/index.js");
const {
  PermissionFlagsBits,
  CommandInteraction,
  InteractionType,
} = require("discord.js");

class InteractionCreate extends Events {
  constructor(client, file) {
    super(client, file, {
      name: "interactionCreate",
      once: false,
    });
  }
  /**
   * @param {CommandInteraction} interaction
   * @param { MainClient } client
   */
  async execute(interaction, client) {

    if (
      !interaction instanceof CommandInteraction &&
      interaction.type !== InteractionType.ApplicationCommand
    )
      return;

    if (interaction.channel.type === "DM")
      return await interaction.reply({
        content: `**${interaction.user.displayName}**, You cannot use slash command's in the DM channels!`,
        ephemeral: true,
      });

    let { commandName } = interaction;
    let me = interaction.guild.members.me;
    let author = interaction.member;
    let channel = interaction.channel;
    let command = client.commands.get(commandName);
    if (!command) return;

    const ctx = new Context(interaction, interaction.options.data);
    ctx.setArgs(interaction.options.data);

    const cooldown = client.cooldowns.get(
      `${command.name}-${interaction.user.id}`
    );

    if (command.cooldown && cooldown) {
      let remainingTime = Date.now() - cooldown;
      if (Date.now() < cooldown) {
        return await interaction
          .reply({
            content: `**⏱ | ${
              interaction.member.displayName
            }!** Slow down and try the command again **<t:${Math.floor(
              (Date.now() + cooldown - Date.now()) / 1000
            )}:R>**`,
            ephemeral: true,
          })
          .then((m) =>
            setTimeout(
              async () => await m.delete().catch((_) => null),
              remainingTime
            )
          );
      }

      client.cooldowns.set(
        `${command.name}-${interaction.user.id}`,
        Date.now() + command.cooldown * 1000
      );
      setTimeout(
        () => client.cooldowns.delete(`${command.name}-${interaction.user.id}`),
        command.cooldown * 1000
      );
    } else if (command.cooldown && !cooldown) {
      client.cooldowns.set(
        `${command.name}-${interaction.user.id}`,
        Date.now() + command.cooldown * 1000
      );
    }

    if (
      !interaction.inGuild() ||
      !channel.permissionsFor(me).has(PermissionFlagsBits.ViewChannel)
    )
      return;

    if (!me.permissions.has(PermissionFlagsBits.SendMessages))
      return await interaction.reply({
        content: `\`❌\` | I Don't Have **SendMessages** Permission!`,
        ephemeral: true,
      });

    if (!me.permissions.has(PermissionFlagsBits.EmbedLinks))
      return await interaction.reply({
        content: `\`❌\` | I Don't Have **EmbedLinks** Permission!`,
        ephemeral: true,
      });

    if (command.botPermissions) {
      let missingPerms = [];
      command.botPermissions.forEach((perm) => {
        if (
          !me.permissions.has(perm) &&
          !channel.permissionsFor(me).has(perm)
        ) {
          missingPerms.push(perm);
        }
      });
      if (missingPerms.length) {
        return await interaction.reply({
          content: `\`❌\` | I Don't Have **${missingPerms.join(
            ", "
          )}** Permissions!`,
          ephemeral: true,
        });
      }
    }

    if (command.userPermissions) {
      let missingPerms = [];
      command.userPermissions.forEach((perm) => {
        if (!author.permissions.has(perm)) {
          missingPerms.push(perm);
        }
      });
      if (missingPerms.length) {
        return await interaction.reply({
          content: `\`❌\` | You Don't Have **${missingPerms.join(
            ", "
          )}** Permissions!`,
          ephemeral: true,
        });
      }
    }

    if (
      command.devOnly === true &&
      !client.config.dev.includes(interaction.user.id)
    ) {
      return await interaction.reply({
        content: `\`❌\` | This command is only for the developer of the bot! `,
        ephemeral: true,
      });
    }

    try {
      return await command.execute(client, ctx, ctx.args);
    } catch (error) {
      client.logger.error(`Error in ${this.fileName}`);
    }
  }
}

module.exports = InteractionCreate;
