const { Events, MainClient } = require("../../Structures/index.js");
const { REST, Routes, ActivityType } = require("discord.js");

class Ready extends Events {
  constructor(client, file) {
    super(client, file, {
      name: "ready",
      once: true,
    });
  }
  /**
   *
   * @param { MainClient } client
   */
  async execute(client) {
    client.logger.login("Bot Is Online!");
    await client.mongooseConnect(process.env.URI);
    if (client.config.status) {
      client.user.setPresence({
        status: "online",
        activities: [
          {
            name: client.config.status,
            type: ActivityType.Listening,
          },
        ],
      });
    }
    if (client.config.slashRefresh === true) {
      const applicationCommands = Routes.applicationCommands(client.user.id);
      try {
        client.logger.info(`Refreshing Slash Commands!`);
        const rest = new REST({ version: "10" }).setToken(
          client.config.token || process.env.TOKEN
        );
        await rest.put(applicationCommands, {
          body: client.commandsArray,
        });
        client.logger.success(`Registered Slash Commands!`);
      } catch (error) {
        client.logger.error("Error refreshing slash commands!");
        console.error(error);
      }
    }
  }
}

module.exports = Ready;
