const { MainClient } = require("../Structures/index.js");
const { Message } = require("discord.js");

/**
 *
 * @param { MainClient } client
 * @param { Message } message
 */
module.exports = async (client, message) => {
  if (message.author.bot) return;
  if (message.channel.type === "DM") return;
  let data = await client.db.getSticky(message.channel.id);
  if (!data) return;
  let channelId = data ? data.channelId : null;
  let msg = data ? data.message : null;
  let oldMessageId = data ? data.oldMessageId : null;
  if (message.channel.id !== channelId) return;
  let fetch = await message.channel.messages
    .fetch(oldMessageId)
    .catch((_) => null);
  if (fetch) {
    await fetch.delete().catch((_) => null);
  }
  let m = await message.channel.send({
    content: msg,
    allowedMentions: { parse: [] },
  });
  await client.db.setSticky(channelId, msg, m.id);
};
