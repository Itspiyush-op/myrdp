class Commands {
  constructor(client, options) {
    this.client = client;
    this.name = options.name;
    this.description = options.description || "No description provided";
    this.usage = options.usage || "No usage provided";
    this.aliases = options.aliases || [];
    this.cooldown = options.cooldown || 3;
    this.category = options.category || "General";
    this.args = options.args || false;
    this.slash = options.slash || false;
    this.options = options.options || [];
    this.devOnly = options.devOnly || false;
    this.slashOnly = options.slashOnly || false;
    this.userPermissions = options.userPermissions || null;
    this.botPermissions = options.botPermissions || [
      "SendMessages",
      "EmbedLinks",
      "ViewChannel",
    ];
  }
  async execute(_client, _ctx, _args) {
    return await Promise.resolve();
  }
}

module.exports = Commands;
