const Discord = require("discord.js");
const config = require("../../../config.json");
const fs = require("fs");
const Database = require("../../Database/Database.js");
const mongoose = require("mongoose");
const Logger = require("./Logger.js");
const AntiCrash = require("../../Functions/AntiCrash.js");
const {
  Client,
  EmbedBuilder,
  PermissionsBitField,
  ApplicationCommandType,
  Collection,
} = Discord;

class MainClient extends Client {
  constructor(ClientOptions) {
    super(ClientOptions);

    this.config = config;
    this.prefix = config.prefix;
    this.logger = new Logger();
    this.db = new Database();
    this.commands = new Collection();
    this.aliases = new Collection();
    this.cooldowns = new Collection();
    this.commandsArray = [];
  }

  async mongooseConnect(uri) {
    try {
      await mongoose.connect(uri);
      this.logger.login("MongoDB Connected!");
    } catch (error) {
      this.logger.error("MongoDB connection error");
      process.exit(1);
    }
  }

  start(token) {
    console.clear();
    this.loadCommands();
    this.logger.success(`Commands Loaded!`);
    this.loadEvents();
    this.logger.success("Events Loaded!");
    AntiCrash(this);
    this.logger.success("AntiCrash System Loaded!")
    super.login(token);
  }
  embed() {
    const embed = new EmbedBuilder().setColor(config.embedColor).setFooter({
      text: `Dev: @${config.devName}`,
    });
    return embed;
  }

  loadCommands() {
    let path = fs.readdirSync("./src/Commands");
    path.forEach((dir) => {
      try {
        let commands = fs
          .readdirSync(`./src/Commands/${dir}`)
          .filter((file) => file.endsWith(".js"));
        commands.forEach((file) => {
          try {
            let CommandClass = require(`../../Commands/${dir}/${file}`);
            let command = new CommandClass(this);
            command.category = dir;
            this.commands.set(command.name, command);
            if (command.aliases.length !== 0) {
              command.aliases.forEach((alias) =>
                this.aliases.set(alias, command.name)
              );
            }
            if (command.slash) {
              let data = {
                name: command.name,
                description: command.description,
                type: ApplicationCommandType.ChatInput,
                options: command.options || null,
                default_member_permissions:
                  command.userPermissions.length > 0
                    ? command.userPermissions
                    : null,
              };
              if (command.userPermissions.length > 0) {
                let permsValue = PermissionsBitField.resolve(
                  command.userPermissions
                );
                if (typeof permsValue === "bigint") {
                  data.default_member_permissions = permsValue.toString();
                } else {
                  data.default_member_permissions = permsValue;
                }
              }
              let json = JSON.stringify(data);
              this.commandsArray.push(JSON.parse(json));
            }
          } catch (error) {
            this.logger.error(`Error loading command ${file}`);
          }
        });
      } catch (error) {
        this.logger.error(`Error loading command directory ${dir}`);
      }
    });
  }

  loadEvents() {
    let path = fs.readdirSync("./src/Events");
    path.forEach((dir) => {
      try {
        let events = fs
          .readdirSync(`./src/Events/${dir}`)
          .filter((file) => file.endsWith(".js"));
        events.forEach((file) => {
          try {
            let EventClass = require(`../../Events/${dir}/${file}`);
            let event = new EventClass(this, file);
            switch (event.once) {
              case true:
                this.once(event.name, (...args) =>
                  event.execute(...args, this)
                );
                break;
              case false:
                this.on(event.name, (...args) => event.execute(...args, this));
              default:
                break;
            }
          } catch (error) {
            this.logger.error(`Error loading event ${file}`);
          }
        });
      } catch (error) {
        this.logger.error(`Error reading directory ${dir}`);
      }
    });
  }
}

module.exports = MainClient;
